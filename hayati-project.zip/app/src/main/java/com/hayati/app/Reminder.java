package com.hayati.app;

import android.Manifest;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

import java.util.Calendar;
import java.util.Random;

public class Reminder {
    static final String CH = "water";

    static final String[] MSGS = {
            "قوم اشرب كاس مي 💧 جسمك بيشكرك",
            "استراحة صغيرة: كاس مي وكمّل",
            "كاس مي هلأ بيفرق بتركيزك",
            "لا تنسى المي اليوم، خطوة صغيرة وبتوصل لهدفك"
    };

    static PendingIntent pi(Context c) {
        return PendingIntent.getBroadcast(c, 1, new Intent(c, ReminderReceiver.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    public static void schedule(Context c) {
        Store s = new Store(c);
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent p = pi(c);
        am.cancel(p);
        if (!s.b("remOn", true)) return;
        long t = System.currentTimeMillis() + s.i("remEvery", 90) * 60000L;
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, p);
    }

    public static void fire(Context c) {
        Store s = new Store(c);
        if (s.b("remOn", true)) {
            int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
            boolean inWindow = h >= s.i("remStart", 8) && h < s.i("remEnd", 22);
            boolean notDone = s.water(Store.today()) < WaterCalc.goal(s);
            if (inWindow && notDone) notifyNow(c, MSGS[new Random().nextInt(MSGS.length)]);
        }
        schedule(c);
    }

    public static boolean canNotify(Context c) {
        return Build.VERSION.SDK_INT < 33
                || c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                == PackageManager.PERMISSION_GRANTED;
    }

    public static void notifyNow(Context c, String text) {
        if (!canNotify(c)) return;
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CH, "تذكير الماء",
                    NotificationManager.IMPORTANCE_DEFAULT));
        }
        PendingIntent open = PendingIntent.getActivity(c, 0, new Intent(c, MainActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(c, CH) : new Notification.Builder(c);
        b.setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle("حياتي")
                .setContentText(text)
                .setContentIntent(open)
                .setAutoCancel(true);
        nm.notify(100, b.build());
    }
}
