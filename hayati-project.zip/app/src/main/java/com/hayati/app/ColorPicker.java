package com.hayati.app;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.text.InputFilter;
import android.view.View;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

public class ColorPicker {
    public interface OnPick { void pick(int color); }

    static final int[] PAL = {
            0xFF1E88E5, 0xFF43A047, 0xFFE53935, 0xFFFB8C00, 0xFF8E24AA, 0xFF00ACC1,
            0xFFD81B60, 0xFF6D4C41, 0xFF546E7A, 0xFFFDD835, 0xFF3949AB, 0xFF00897B,
            0xFFFFFFFF, 0xFFEDEFF2, 0xFF9E9E9E, 0xFF1A1D21, 0xFF0F1419, 0xFF000000
    };

    public static void show(Context c, String title, int cur, final OnPick cb) {
        final int[] sel = {cur};
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(Style.dp(16), Style.dp(8), Style.dp(16), Style.dp(8));
        col.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        final EditText hex = new EditText(c);
        hex.setSingleLine(true);
        hex.setFilters(new InputFilter[]{new InputFilter.LengthFilter(6)});
        hex.setText(String.format("%06X", cur & 0xFFFFFF));

        GridLayout g = new GridLayout(c);
        g.setColumnCount(6);
        for (final int p : PAL) {
            View v = new View(c);
            GradientDrawable d = new GradientDrawable();
            d.setShape(GradientDrawable.OVAL);
            d.setColor(p);
            d.setStroke(Style.dp(1), 0x55888888);
            v.setBackground(d);
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = Style.dp(40);
            lp.height = Style.dp(40);
            lp.setMargins(Style.dp(5), Style.dp(5), Style.dp(5), Style.dp(5));
            v.setLayoutParams(lp);
            v.setOnClickListener(x -> {
                sel[0] = p;
                hex.setText(String.format("%06X", p & 0xFFFFFF));
            });
            g.addView(v);
        }
        col.addView(g);
        TextView t = new TextView(c);
        t.setText("أو اكتب رمز اللون (6 خانات)");
        t.setPadding(0, Style.dp(10), 0, 0);
        col.addView(t);
        col.addView(hex);

        new AlertDialog.Builder(c)
                .setTitle(title)
                .setView(col)
                .setPositiveButton("تطبيق", (dlg, which) -> {
                    int res = sel[0];
                    try {
                        String s = hex.getText().toString().trim();
                        if (s.length() == 6) res = Color.parseColor("#" + s);
                    } catch (Exception ignored) {
                    }
                    cb.pick(res | 0xFF000000);
                })
                .setNegativeButton("إلغاء", null)
                .show();
    }
}
