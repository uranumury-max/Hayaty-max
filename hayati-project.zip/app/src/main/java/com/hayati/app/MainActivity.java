package com.hayati.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {

    interface IntCb { void on(int i); }

    static final int M = ViewGroup.LayoutParams.MATCH_PARENT;
    static final int W = ViewGroup.LayoutParams.WRAP_CONTENT;

    static final String[] SECS = {"الرئيسية", "الصحة", "الإعدادات"};
    static final String[] ICONS = {"🏠", "💧", "⚙️"};
    static final String[][] SUBS = {
            {},
            {"الماء", "الإحصائيات", "التذكير"},
            {"الملف الشخصي", "المظهر", "الأذونات", "النسخ الاحتياطي"}
    };
    static final String[] ROLES = {"طالب", "موظف", "رب بيت", "عمل حر"};

    Store st;
    FrameLayout root;
    LinearLayout page, content, subTabs, nav;
    HorizontalScrollView subScroll;
    ScrollView scroll;
    TextView topTitle, topAge, footer;
    View overlay;
    boolean overlayLocked = false, permStep = false;
    int section = 0, sub = 0;
    WaterRingView ring;
    TextView waterInfo;
    EditText backupBox;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        st = new Store(this);
        setContentView(R.layout.activity_main);
        root = findViewById(R.id.root);
        page = findViewById(R.id.page);
        content = findViewById(R.id.content);
        subTabs = findViewById(R.id.subTabs);
        nav = findViewById(R.id.nav);
        subScroll = findViewById(R.id.subScroll);
        scroll = findViewById(R.id.scroll);
        topTitle = findViewById(R.id.topTitle);
        topAge = findViewById(R.id.topAge);
        footer = findViewById(R.id.footer);
        Style.load(this, st);
        applyTheme();
        rebuild();
        if (!st.b("setupDone", false)) showProfileForm(true);
        else Reminder.schedule(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (st != null) updateTop();
    }

    @Override
    public void onBackPressed() {
        if (overlayLocked) return;
        if (overlay != null) {
            root.removeView(overlay);
            overlay = null;
            return;
        }
        if (section != 0) {
            section = 0;
            sub = 0;
            rebuild();
            return;
        }
        super.onBackPressed();
    }

    // ---------------------------------------------------------------- shell

    void applyTheme() {
        page.setBackground(Style.pageBg());
        topTitle.setTextColor(Style.text);
        topAge.setTextColor(Style.sub);
        footer.setTextColor(Style.sub);
        nav.setBackgroundColor(Style.card);
        getWindow().setStatusBarColor(Style.bg);
        getWindow().setNavigationBarColor(Style.card);
        getWindow().getDecorView().setSystemUiVisibility(
                Style.dark ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
    }

    void restyle() {
        Style.load(this, st);
        applyTheme();
        rebuild();
    }

    void rebuild() {
        buildNav();
        buildSubs();
        render();
    }

    void updateTop() {
        int[] a = AgeCalc.age(st.s("birth", ""));
        topAge.setText(a == null
                ? "حدد تاريخ ميلادك من الإعدادات ليُحسب عمرك تلقائياً"
                : "عمرك: " + a[0] + " سنة، " + a[1] + " شهر، " + a[2] + " يوم");
    }

    void buildNav() {
        nav.removeAllViews();
        for (int i = 0; i < SECS.length; i++) {
            final int idx = i;
            boolean on = i == section;
            LinearLayout it = new LinearLayout(this);
            it.setOrientation(LinearLayout.VERTICAL);
            it.setGravity(Gravity.CENTER);
            it.setPadding(0, Style.dp(8), 0, Style.dp(8));
            it.addView(Style.tv(this, ICONS[i], 20, Style.text, false));
            it.addView(Style.tv(this, SECS[i], 11, on ? Style.accent : Style.sub, on));
            it.setOnClickListener(v -> {
                section = idx;
                sub = 0;
                rebuild();
                scroll.scrollTo(0, 0);
            });
            nav.addView(it, new LinearLayout.LayoutParams(0, W, 1));
        }
    }

    void buildSubs() {
        subTabs.removeAllViews();
        String[] s = SUBS[section];
        subScroll.setVisibility(s.length == 0 ? View.GONE : View.VISIBLE);
        for (int i = 0; i < s.length; i++) {
            final int idx = i;
            Button b = Style.chip(this, s[i], i == sub);
            b.setPadding(Style.dp(16), 0, Style.dp(16), 0);
            b.setOnClickListener(v -> {
                sub = idx;
                buildSubs();
                render();
                scroll.scrollTo(0, 0);
            });
            subTabs.addView(b, Style.lp(W, Style.dp(38), 6, 4, 6, 4));
        }
    }

    void render() {
        content.removeAllViews();
        ring = null;
        waterInfo = null;
        updateTop();
        if (section == 0) renderHome();
        else if (section == 1) {
            if (sub == 0) renderWater();
            else if (sub == 1) renderStats();
            else renderReminders();
        } else {
            if (sub == 0) renderProfile();
            else if (sub == 1) renderAppearance();
            else if (sub == 2) renderPerms();
            else renderBackup();
        }
    }

    // ---------------------------------------------------------------- helpers

    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    void rtl(View v) { v.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); }

    TextView title(String t) { return Style.tv(this, t, 16, Style.text, true); }

    TextView line(String t, float topMargin) {
        TextView v = Style.tv(this, t, 14, Style.text, false);
        v.setLayoutParams(Style.lp(M, W, 0, topMargin, 0, 0));
        return v;
    }

    View chips(String[] opts, int sel, final IntCb cb) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        final Button[] bs = new Button[opts.length];
        for (int i = 0; i < opts.length; i++) {
            final int idx = i;
            Button b = Style.chip(this, opts[i], i == sel);
            b.setOnClickListener(v -> {
                for (int j = 0; j < bs.length; j++) Style.paintChip(bs[j], j == idx);
                cb.on(idx);
            });
            bs[i] = b;
            row.addView(b, Style.lp(0, W, 3, 0, 3, 0));
            ((LinearLayout.LayoutParams) b.getLayoutParams()).weight = 1;
        }
        return row;
    }

    View stepper(String label, final int value, final int min, final int max, final String suffix,
                 final IntCb cb) {
        final int[] cur = {value};
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setLayoutParams(Style.lp(M, W, 0, 10, 0, 0));
        row.addView(Style.tv(this, label, 14, Style.text, false), new LinearLayout.LayoutParams(0, W, 1));
        final TextView val = Style.tv(this, cur[0] + suffix, 15, Style.text, true);
        Button minus = Style.chip(this, "−", false);
        Button plus = Style.chip(this, "+", false);
        minus.setOnClickListener(v -> {
            if (cur[0] > min) {
                cur[0]--;
                val.setText(cur[0] + suffix);
                cb.on(cur[0]);
            }
        });
        plus.setOnClickListener(v -> {
            if (cur[0] < max) {
                cur[0]++;
                val.setText(cur[0] + suffix);
                cb.on(cur[0]);
            }
        });
        row.addView(minus, new LinearLayout.LayoutParams(Style.dp(44), Style.dp(40)));
        val.setGravity(Gravity.CENTER);
        row.addView(val, new LinearLayout.LayoutParams(Style.dp(64), W));
        row.addView(plus, new LinearLayout.LayoutParams(Style.dp(44), Style.dp(40)));
        return row;
    }

    boolean notifGranted() { return Reminder.canNotify(this); }

    void askNotif(int code) {
        if (Build.VERSION.SDK_INT >= 33 && !notifGranted()) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, code);
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (permStep) finishSetup();
        else if (st != null) render();
    }

    // ---------------------------------------------------------------- home

    String moodText() {
        switch (st.i("mood", 0)) {
            case 1:
                return "خذ نفساً عميقاً، خفف الضغط وركز على مهمة واحدة أساسية بس.";
            case 2:
                return "جدولك مرن اليوم، وانتبه لشرب الماء أكتر من العادة.";
            default:
                return "يوم عادي، رتب مهامك وكمّل بثبات، إنت قدها.";
        }
    }

    void renderHome() {
        LinearLayout g = Style.card(this);
        g.addView(Style.tv(this, "أهلاً " + st.s("name", "") + " 👋", 20, Style.text, true));
        TextView m = Style.tv(this, moodText(), 14, Style.sub, false);
        m.setLayoutParams(Style.lp(M, W, 0, 6, 0, 0));
        g.addView(m);
        content.addView(g);

        LinearLayout mc = Style.card(this);
        mc.addView(title("حالتك اليوم"));
        View ch = chips(new String[]{"عادية", "متوتر / مرهق", "في سفر"}, st.i("mood", 0), i -> {
            st.put("mood", i);
            render();
        });
        ch.setLayoutParams(Style.lp(M, W, 0, 10, 0, 0));
        mc.addView(ch);
        content.addView(mc);

        content.addView(waterCard(true));

        int goal = WaterCalc.goal(st);
        int cur = st.water(Store.today());
        LinearLayout sc = Style.card(this);
        sc.addView(title("ملخص اليوم"));
        sc.addView(line("💧 إنجاز الماء: " + Math.min(100, cur * 100 / goal) + "%", 8));
        content.addView(sc);
    }

    // ---------------------------------------------------------------- water

    String goalText(int goal) {
        return "الهدف اليومي: " + goal + " مل ("
                + String.format(Locale.US, "%.1f", goal / 1000f) + " لتر) ≈ "
                + Math.round(goal / 250f) + " كوب\nشربت اليوم: " + st.water(Store.today()) + " مل";
    }

    LinearLayout waterCard(boolean compact) {
        final int goal = WaterCalc.goal(st);
        LinearLayout c = Style.card(this);
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        c.addView(title("💧 الماء اليوم"));
        ring = new WaterRingView(this);
        int size = Style.dp(compact ? 180 : 230);
        c.addView(ring, Style.lp(size, size, 0, 10, 0, 6));
        ring.setData(st.water(Store.today()), goal);
        waterInfo = Style.tv(this, goalText(goal), 13, Style.sub, false);
        waterInfo.setGravity(Gravity.CENTER);
        c.addView(waterInfo);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setLayoutParams(Style.lp(M, W, 0, 12, 0, 0));
        Button add = Style.btn(this, "+ كأس (250 مل)", true);
        Button undo = Style.btn(this, "تراجع", false);
        Button rst = Style.btn(this, "تصفير", false);
        add.setOnClickListener(v -> changeWater(250, goal));
        undo.setOnClickListener(v -> changeWater(-250, goal));
        rst.setOnClickListener(v -> {
            st.resetWater();
            changeWater(0, goal);
        });
        row.addView(add, Style.lp(0, W, 3, 0, 3, 0));
        row.addView(undo, Style.lp(0, W, 3, 0, 3, 0));
        row.addView(rst, Style.lp(0, W, 3, 0, 3, 0));
        ((LinearLayout.LayoutParams) add.getLayoutParams()).weight = 2;
        ((LinearLayout.LayoutParams) undo.getLayoutParams()).weight = 1;
        ((LinearLayout.LayoutParams) rst.getLayoutParams()).weight = 1;
        c.addView(row);
        return c;
    }

    void changeWater(int ml, int goal) {
        int before = st.water(Store.today());
        if (ml != 0) st.addWater(ml);
        int now = st.water(Store.today());
        if (ring != null) ring.setData(now, goal);
        if (waterInfo != null) waterInfo.setText(goalText(goal));
        if (before < goal && now >= goal) toast("ما شاء الله، حققت هدف الماء اليوم 🎉");
    }

    void renderWater() {
        content.addView(waterCard(false));
    }

    void renderStats() {
        int goal = WaterCalc.goal(st);
        LinearLayout c = Style.card(this);
        c.addView(title("شربك آخر 7 أيام (مل)"));
        int[] v = new int[7];
        String[] l = new String[7];
        int sum = 0, hit = 0;
        SimpleDateFormat f = new SimpleDateFormat("EEE", new Locale("ar"));
        for (int i = 6; i >= 0; i--) {
            int ml = st.water(Store.dayKey(i));
            v[6 - i] = ml;
            sum += ml;
            if (ml >= goal) hit++;
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DAY_OF_YEAR, -i);
            l[6 - i] = f.format(cal.getTime());
        }
        BarChartView ch = new BarChartView(this);
        ch.set(v, l, goal);
        c.addView(ch, Style.lp(M, W, 0, 10, 0, 0));
        c.addView(line("الخط المتقطع = هدفك اليومي (" + goal + " مل)", 6));
        content.addView(c);

        LinearLayout s = Style.card(this);
        s.addView(title("ملخص"));
        s.addView(line("المتوسط: " + (sum / 7) + " مل يومياً", 8));
        s.addView(line("حققت الهدف في " + hit + " من 7 أيام", 6));
        content.addView(s);
    }

    void renderReminders() {
        LinearLayout c = Style.card(this);
        c.addView(title("تذكير شرب الماء"));
        Switch sw = new Switch(this);
        sw.setText("تفعيل التذكير");
        sw.setTextColor(Style.text);
        sw.setChecked(st.b("remOn", true));
        sw.setLayoutParams(Style.lp(M, W, 0, 10, 0, 0));
        sw.setOnCheckedChangeListener((b, on) -> {
            st.put("remOn", on);
            if (on) askNotif(8);
            Reminder.schedule(this);
        });
        c.addView(sw);

        c.addView(line("كل كم دقيقة أذكّرك؟", 14));
        int ev = st.i("remEvery", 90);
        int sel = ev == 60 ? 0 : (ev == 120 ? 2 : 1);
        View ch = chips(new String[]{"60", "90", "120"}, sel, i -> {
            st.put("remEvery", i == 0 ? 60 : (i == 2 ? 120 : 90));
            Reminder.schedule(this);
        });
        ch.setLayoutParams(Style.lp(M, W, 0, 8, 0, 0));
        c.addView(ch);

        c.addView(stepper("يبدأ التذكير الساعة", st.i("remStart", 8), 0, 22, ":00", v -> {
            st.put("remStart", v);
            if (v >= st.i("remEnd", 22)) st.put("remEnd", Math.min(23, v + 1));
        }));
        c.addView(stepper("ينتهي الساعة", st.i("remEnd", 22), 1, 23, ":00", v -> {
            st.put("remEnd", v);
            if (v <= st.i("remStart", 8)) st.put("remStart", Math.max(0, v - 1));
        }));
        c.addView(line("التذكير يتوقف تلقائياً بعد بلوغ هدف الماء. أندرويد قد يؤخر التنبيه دقائق لتوفير البطارية.", 14));
        Button test = Style.btn(this, "اختبار التنبيه الآن", true);
        test.setOnClickListener(v -> {
            if (notifGranted()) Reminder.notifyNow(this, "تجربة: قوم اشرب كاس مي 💧");
            else {
                toast("اسمح بالإشعارات أولاً");
                askNotif(9);
            }
        });
        c.addView(test, Style.lp(M, W, 0, 12, 0, 0));
        content.addView(c);
    }

    // ---------------------------------------------------------------- settings

    void renderProfile() {
        LinearLayout c = Style.card(this);
        c.addView(title("بطاقة التعريف"));
        int r = Math.max(0, Math.min(3, st.i("role", 0)));
        c.addView(line("الاسم: " + st.s("name", ""), 10));
        c.addView(line("الجنس: " + (st.i("gender", 0) == 0 ? "ذكر" : "أنثى"), 6));
        c.addView(line("الصفة: " + ROLES[r], 6));
        c.addView(line("الوزن: " + st.s("weight", "") + " كغ", 6));
        c.addView(line("الطول: " + st.s("height", "") + " سم", 6));
        c.addView(line("تاريخ الميلاد: " + st.s("birth", ""), 6));
        Button e = Style.btn(this, "تعديل بياناتي", true);
        e.setOnClickListener(v -> showProfileForm(false));
        c.addView(e, Style.lp(M, W, 0, 14, 0, 0));
        content.addView(c);
    }

    View colorRow(final String label, final String key, final int cur) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, Style.dp(8), 0, Style.dp(8));
        r.addView(Style.tv(this, label, 15, Style.text, false), new LinearLayout.LayoutParams(0, W, 1));
        View sw = new View(this);
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(cur);
        d.setStroke(Style.dp(2), Style.sub);
        sw.setBackground(d);
        r.addView(sw, new LinearLayout.LayoutParams(Style.dp(34), Style.dp(34)));
        r.setOnClickListener(v -> ColorPicker.show(this, label, cur, col -> {
            st.put(key, col);
            restyle();
        }));
        return r;
    }

    void renderAppearance() {
        LinearLayout m = Style.card(this);
        m.addView(title("الوضع"));
        View ch = chips(new String[]{"تلقائي", "نهاري", "ليلي"}, st.i("mode", 0), i -> {
            st.put("mode", i);
            restyle();
        });
        ch.setLayoutParams(Style.lp(M, W, 0, 10, 0, 0));
        m.addView(ch);
        content.addView(m);

        LinearLayout t = Style.card(this);
        t.addView(title("شكل البطاقات (اضغط على النمط لتطبيقه)"));
        content.addView(t);
        String[] names = {"كلاسيكي واضح", "دائري واسع", "بإطار بارز", "متدرج", "زجاجي شفاف"};
        String[] desc = {"حواف محددة وظل خفيف", "زوايا دائرية وظل واضح", "إطار بلون التمييز",
                "تدرج لوني مع لون التمييز", "شبه شفاف وإطار منسجم"};
        for (int k = 1; k <= 5; k++) {
            final int kk = k;
            int keep = Style.cardStyle;
            Style.cardStyle = k;
            LinearLayout pc = Style.card(this);
            Style.cardStyle = keep;
            boolean on = keep == k;
            pc.addView(Style.tv(this, (on ? "✓ " : "") + names[k - 1], 15, Style.text, true));
            pc.addView(line(desc[k - 1], 4));
            pc.setOnClickListener(v -> {
                st.put("cardStyle", kk);
                restyle();
            });
            content.addView(pc);
        }

        LinearLayout c = Style.card(this);
        c.addView(title("الألوان"));
        c.addView(colorRow("اللون الرئيسي", "cAccent", Style.accent));
        c.addView(colorRow("لون الكتابة", "cText", Style.text));
        c.addView(colorRow("لون الكروت", "cCard", Style.card));
        c.addView(colorRow("لون العناصر المهمة", "cImp", Style.important));
        c.addView(colorRow("لون الخلفية", "cBg", Style.bg));
        Button reset = Style.btn(this, "إعادة الألوان الافتراضية", false);
        reset.setOnClickListener(v -> {
            for (String k : new String[]{"cAccent", "cText", "cCard", "cImp", "cBg"}) st.remove(k);
            restyle();
        });
        c.addView(reset, Style.lp(M, W, 0, 10, 0, 0));
        content.addView(c);
    }

    void renderPerms() {
        LinearLayout c = Style.card(this);
        c.addView(title("🔔 الإشعارات"));
        c.addView(line(notifGranted() ? "الحالة: مفعّلة ✅" : "الحالة: غير مفعّلة ❌", 8));
        c.addView(line("تُستخدم لتذكيرك بشرب الماء. يمكنك إيقافها في أي وقت من إعدادات الهاتف.", 6));
        Button allow = Style.btn(this, "السماح بالإشعارات", true);
        allow.setOnClickListener(v -> {
            if (notifGranted()) toast("الإشعارات مفعّلة أصلاً");
            else askNotif(10);
        });
        Button open = Style.btn(this, "فتح إعدادات التطبيق", false);
        open.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + getPackageName()))));
        c.addView(allow, Style.lp(M, W, 0, 12, 0, 0));
        c.addView(open, Style.lp(M, W, 0, 8, 0, 0));
        content.addView(c);
    }

    void renderBackup() {
        LinearLayout c = Style.card(this);
        c.addView(title("نسخ احتياطي واستعادة"));
        c.addView(line("اضغط «تصدير» لتظهر بياناتك كنص، انسخه واحفظه. ولاستعادتها الصق النص بالمربع ثم اضغط «استعادة».", 8));
        backupBox = new EditText(this);
        backupBox.setTextColor(Style.text);
        backupBox.setTextSize(12);
        backupBox.setMinLines(6);
        backupBox.setGravity(Gravity.TOP | Gravity.START);
        backupBox.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        GradientDrawable g = Style.round(Style.card, 12);
        g.setStroke(Style.dp(1), Style.blend(Style.text, Style.card, 0.7f));
        backupBox.setBackground(g);
        backupBox.setPadding(Style.dp(10), Style.dp(10), Style.dp(10), Style.dp(10));
        c.addView(backupBox, Style.lp(M, W, 0, 10, 0, 0));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button ex = Style.btn(this, "تصدير", true);
        Button cp = Style.btn(this, "نسخ", false);
        Button rs = Style.btn(this, "استعادة", false);
        ex.setOnClickListener(v -> backupBox.setText(exportJson()));
        cp.setOnClickListener(v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("hayati", backupBox.getText().toString()));
            toast("تم النسخ");
        });
        rs.setOnClickListener(v -> restore(backupBox.getText().toString()));
        for (Button b : new Button[]{ex, cp, rs}) {
            row.addView(b, Style.lp(0, W, 3, 0, 3, 0));
            ((LinearLayout.LayoutParams) b.getLayoutParams()).weight = 1;
        }
        c.addView(row, Style.lp(M, W, 0, 10, 0, 0));
        content.addView(c);
    }

    String exportJson() {
        try {
            JSONObject o = new JSONObject();
            o.put("_app", "hayati");
            o.put("_v", 1);
            JSONObject d = new JSONObject();
            for (Map.Entry<String, ?> en : st.sp.getAll().entrySet()) d.put(en.getKey(), en.getValue());
            o.put("data", d);
            return o.toString(2);
        } catch (Exception e) {
            return "";
        }
    }

    void restore(String txt) {
        try {
            JSONObject o = new JSONObject(txt.trim());
            if (!"hayati".equals(o.optString("_app"))) throw new Exception("bad");
            JSONObject d = o.getJSONObject("data");
            SharedPreferences.Editor e = st.sp.edit();
            e.clear();
            Iterator<String> it = d.keys();
            while (it.hasNext()) {
                String k = it.next();
                Object v = d.get(k);
                if (v instanceof Boolean) e.putBoolean(k, (Boolean) v);
                else if (v instanceof Integer) e.putInt(k, (Integer) v);
                else if (v instanceof Long) e.putLong(k, (Long) v);
                else if (v instanceof Double) e.putFloat(k, ((Double) v).floatValue());
                else e.putString(k, String.valueOf(v));
            }
            e.apply();
            Reminder.schedule(this);
            restyle();
            toast("تمت الاستعادة بنجاح ✅");
        } catch (Exception ex) {
            toast("النص غير صالح، ولم يتغير شيء");
        }
    }

    // ---------------------------------------------------------------- profile form / setup

    EditText field(int type) {
        EditText e = new EditText(this);
        e.setInputType(type);
        e.setSingleLine(true);
        e.setTextColor(Style.text);
        e.setTextSize(16);
        e.setPadding(Style.dp(12), Style.dp(10), Style.dp(12), Style.dp(10));
        GradientDrawable g = Style.round(Style.card, 12);
        g.setStroke(Style.dp(1), Style.blend(Style.text, Style.card, 0.7f));
        e.setBackground(g);
        e.setLayoutParams(Style.lp(M, W, 0, 6, 0, 0));
        return e;
    }

    void label(LinearLayout col, String t) {
        TextView v = Style.tv(this, t, 14, Style.text, true);
        v.setLayoutParams(Style.lp(M, W, 0, 16, 0, 0));
        col.addView(v);
    }

    float num(String s) {
        try {
            return Float.parseFloat(s.trim().replace(',', '.'));
        } catch (Exception e) {
            return -1;
        }
    }

    void showProfileForm(final boolean first) {
        final ScrollView sv = new ScrollView(this);
        sv.setBackground(Style.pageBg());
        sv.setClickable(true);
        rtl(sv);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(Style.dp(20), Style.dp(28), Style.dp(20), Style.dp(28));
        sv.addView(col);
        col.addView(Style.tv(this, first ? "أهلاً بك في حياتي" : "تعديل ملفك الشخصي", 24, Style.text, true));
        TextView intro = Style.tv(this, first
                ? "قبل ما نبدأ، عرّفنا عليك. بياناتك بتنحفظ على جهازك فقط."
                : "عدّل بياناتك وتتحدث خطتك مباشرة.", 14, Style.sub, false);
        intro.setLayoutParams(Style.lp(M, W, 0, 6, 0, 0));
        col.addView(intro);

        label(col, "اكتب اسمك");
        final EditText name = field(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        name.setText(st.s("name", ""));
        col.addView(name);

        label(col, "اختر تاريخ ميلادك");
        final String[] birth = {st.s("birth", "")};
        final Button bd = Style.btn(this, birth[0].isEmpty() ? "اضغط للاختيار" : birth[0], false);
        bd.setOnClickListener(v -> {
            int y = 2005, m = 0, d = 1;
            try {
                String[] p = birth[0].split("-");
                y = Integer.parseInt(p[0]);
                m = Integer.parseInt(p[1]) - 1;
                d = Integer.parseInt(p[2]);
            } catch (Exception ignored) {
            }
            DatePickerDialog dlg = new DatePickerDialog(this, (view, yy, mm, dd) -> {
                birth[0] = String.format(Locale.US, "%04d-%02d-%02d", yy, mm + 1, dd);
                bd.setText(birth[0]);
            }, y, m, d);
            dlg.getDatePicker().setMaxDate(System.currentTimeMillis());
            dlg.show();
        });
        col.addView(bd, Style.lp(M, W, 0, 6, 0, 0));

        label(col, "اكتب وزنك بالكيلوغرام");
        final EditText wt = field(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        wt.setText(st.s("weight", ""));
        col.addView(wt);

        label(col, "اكتب طولك بالسنتيمتر");
        final EditText ht = field(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        ht.setText(st.s("height", ""));
        col.addView(ht);

        label(col, "اختر جنسك");
        final int[] gender = {st.i("gender", 0)};
        View gc = chips(new String[]{"ذكر", "أنثى"}, gender[0], i -> gender[0] = i);
        gc.setLayoutParams(Style.lp(M, W, 0, 6, 0, 0));
        col.addView(gc);

        label(col, "اختر صفتك");
        final int[] role = {st.i("role", 0)};
        View rc = chips(ROLES, role[0], i -> role[0] = i);
        rc.setLayoutParams(Style.lp(M, W, 0, 6, 0, 0));
        col.addView(rc);

        final TextView err = Style.tv(this, "", 14, 0xFFE53935, true);
        err.setLayoutParams(Style.lp(M, W, 0, 14, 0, 0));
        col.addView(err);

        Button save = Style.btn(this, "حفظ", true);
        save.setOnClickListener(v -> {
            String n = name.getText().toString().trim();
            float w = num(wt.getText().toString());
            float h = num(ht.getText().toString());
            if (n.isEmpty()) { err.setText("اكتب اسمك"); return; }
            if (birth[0].isEmpty()) { err.setText("اختر تاريخ ميلادك"); return; }
            if (w < 20 || w > 300) { err.setText("اكتب وزناً صحيحاً بالكيلوغرام"); return; }
            if (h < 80 || h > 250) { err.setText("اكتب طولاً صحيحاً بالسنتيمتر"); return; }
            st.put("name", n);
            st.put("birth", birth[0]);
            st.put("weight", wt.getText().toString().trim().replace(',', '.'));
            st.put("height", ht.getText().toString().trim().replace(',', '.'));
            st.put("gender", gender[0]);
            st.put("role", role[0]);
            st.put("setupDone", true);
            root.removeView(sv);
            overlay = null;
            overlayLocked = false;
            if (first) showPermStep();
            else {
                updateTop();
                render();
            }
        });
        col.addView(save, Style.lp(M, W, 0, 6, 0, 0));
        if (!first) {
            Button cancel = Style.btn(this, "إلغاء", false);
            cancel.setOnClickListener(v -> {
                root.removeView(sv);
                overlay = null;
            });
            col.addView(cancel, Style.lp(M, W, 0, 8, 0, 0));
        }
        overlay = sv;
        overlayLocked = first;
        root.addView(sv, new FrameLayout.LayoutParams(M, M));
    }

    void showPermStep() {
        permStep = true;
        overlayLocked = true;
        ScrollView sv = new ScrollView(this);
        sv.setBackground(Style.pageBg());
        sv.setClickable(true);
        rtl(sv);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(Style.dp(20), Style.dp(40), Style.dp(20), Style.dp(28));
        sv.addView(col);
        col.addView(Style.tv(this, "🔔 الإشعارات", 24, Style.text, true));
        TextView t = Style.tv(this,
                "عشان أذكّرك تشرب مي وأنبهك بالمواعيد، التطبيق بحاجة إذنك لإرسال الإشعارات.\n\nهل توافق؟",
                16, Style.text, false);
        t.setLayoutParams(Style.lp(M, W, 0, 14, 0, 0));
        col.addView(t);
        Button yes = Style.btn(this, "أوافق", true);
        yes.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= 33 && !notifGranted()) askNotif(7);
            else finishSetup();
        });
        Button no = Style.btn(this, "ليس الآن", false);
        no.setOnClickListener(v -> finishSetup());
        col.addView(yes, Style.lp(M, W, 0, 24, 0, 0));
        col.addView(no, Style.lp(M, W, 0, 8, 0, 0));
        overlay = sv;
        root.addView(sv, new FrameLayout.LayoutParams(M, M));
    }

    void finishSetup() {
        permStep = false;
        overlayLocked = false;
        if (overlay != null) {
            root.removeView(overlay);
            overlay = null;
        }
        Style.load(this, st);
        applyTheme();
        rebuild();
        Reminder.schedule(this);
    }
}
