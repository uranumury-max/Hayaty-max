package com.hayati.app;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class Style {
    public static final int M = ViewGroup.LayoutParams.MATCH_PARENT;
    public static final int W = ViewGroup.LayoutParams.WRAP_CONTENT;

    public static int bg, card, text, sub, accent, important, cardStyle;
    public static boolean dark;
    public static float density = 3f;

    public static void load(Context c, Store s) {
        density = c.getResources().getDisplayMetrics().density;
        int mode = s.i("mode", 0);
        boolean sysDark = (c.getResources().getConfiguration().uiMode
                & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        dark = mode == 2 || (mode == 0 && sysDark);
        bg = s.i("cBg", dark ? 0xFF0F1419 : 0xFFF2F4F7);
        card = s.i("cCard", dark ? 0xFF1B222C : 0xFFFFFFFF);
        text = s.i("cText", dark ? 0xFFEDEFF2 : 0xFF1A1D21);
        accent = s.i("cAccent", 0xFF1E88E5);
        important = s.i("cImp", 0xFFFF7043);
        sub = blend(text, bg, 0.4f);
        cardStyle = s.i("cardStyle", 1);
    }

    public static int dp(float v) { return (int) (v * density + 0.5f); }

    public static int blend(int a, int b, float t) {
        int r = (int) (Color.red(a) * (1 - t) + Color.red(b) * t);
        int g = (int) (Color.green(a) * (1 - t) + Color.green(b) * t);
        int bl = (int) (Color.blue(a) * (1 - t) + Color.blue(b) * t);
        return Color.rgb(r, g, bl);
    }

    public static int alpha(int c, int a) {
        return Color.argb(a, Color.red(c), Color.green(c), Color.blue(c));
    }

    public static int onColor(int c) {
        double l = (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255.0;
        return l > 0.62 ? 0xFF111111 : 0xFFFFFFFF;
    }

    public static GradientDrawable round(int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    public static Drawable pageBg() {
        return new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{bg, blend(bg, accent, 0.18f)});
    }

    public static Drawable cardBg() {
        GradientDrawable g = new GradientDrawable();
        switch (cardStyle) {
            case 2:
                g.setColor(card);
                g.setCornerRadius(dp(28));
                break;
            case 3:
                g.setColor(card);
                g.setCornerRadius(dp(16));
                g.setStroke(dp(2), accent);
                break;
            case 4:
                g.setOrientation(GradientDrawable.Orientation.TL_BR);
                g.setColors(new int[]{card, blend(card, accent, 0.45f)});
                g.setCornerRadius(dp(18));
                break;
            case 5:
                g.setColor(alpha(card, 0x66));
                g.setCornerRadius(dp(22));
                g.setStroke(dp(1), alpha(accent, 0xAA));
                break;
            default:
                g.setColor(card);
                g.setCornerRadius(dp(4));
                g.setStroke(dp(1), blend(text, card, 0.8f));
                break;
        }
        return g;
    }

    public static LinearLayout card(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(14), dp(16), dp(14));
        l.setBackground(cardBg());
        if (cardStyle == 1) l.setElevation(dp(2));
        if (cardStyle == 2) l.setElevation(dp(8));
        l.setLayoutParams(lp(M, W, 12, 6, 12, 6));
        return l;
    }

    public static LinearLayout.LayoutParams lp(int w, int h, float l, float t, float r, float b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    public static TextView tv(Context c, String t, float sp, int color, boolean bold) {
        TextView v = new TextView(c);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    public static void paintChip(Button b, boolean selected) {
        if (selected) {
            b.setBackground(round(accent, 12));
            b.setTextColor(onColor(accent));
        } else {
            GradientDrawable g = round(card, 12);
            g.setStroke(dp(1), blend(text, card, 0.75f));
            b.setBackground(g);
            b.setTextColor(text);
        }
    }

    public static Button chip(Context c, String t, boolean selected) {
        Button b = new Button(c);
        b.setText(t);
        b.setAllCaps(false);
        b.setTextSize(13);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(dp(8), dp(10), dp(8), dp(10));
        b.setStateListAnimator(null);
        paintChip(b, selected);
        return b;
    }

    public static Button btn(Context c, String t, boolean filled) {
        Button b = chip(c, t, filled);
        b.setTextSize(14);
        b.setPadding(dp(14), dp(12), dp(14), dp(12));
        return b;
    }
}
