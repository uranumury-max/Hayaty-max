package com.hayati.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

public class BarChartView extends View {
    private int[] v = new int[0];
    private String[] l = new String[0];
    private int goal = 2000;
    private final Paint bar = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rf = new RectF();

    public BarChartView(Context c) {
        super(c);
        t.setTextAlign(Paint.Align.CENTER);
    }

    public void set(int[] values, String[] labels, int goal) {
        this.v = values;
        this.l = labels;
        this.goal = Math.max(1, goal);
        invalidate();
    }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        setMeasuredDimension(MeasureSpec.getSize(wSpec), Style.dp(230));
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        float padB = Style.dp(28), padT = Style.dp(20);
        int max = goal;
        for (int x : v) max = Math.max(max, x);
        float chartH = h - padB - padT;
        int n = v.length;
        if (n == 0) return;
        float slot = (float) w / n;
        float bw = slot * 0.5f;

        float gy = padT + chartH * (1f - (float) goal / max);
        line.setColor(Style.important);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(Style.dp(1.5f));
        line.setPathEffect(new DashPathEffect(new float[]{Style.dp(6), Style.dp(5)}, 0));
        c.drawLine(0, gy, w, gy, line);

        for (int i = 0; i < n; i++) {
            float left = w - slot * (i + 1) + (slot - bw) / 2f;
            float top = padT + chartH * (1f - (float) v[i] / max);
            rf.set(left, top, left + bw, padT + chartH);
            bar.setColor(i == n - 1 ? Style.accent : Style.alpha(Style.accent, 0x99));
            c.drawRoundRect(rf, Style.dp(6), Style.dp(6), bar);
            t.setColor(Style.text);
            t.setTextSize(Style.dp(10));
            if (v[i] > 0) c.drawText(String.valueOf(v[i]), left + bw / 2f, top - Style.dp(4), t);
            t.setColor(Style.sub);
            t.setTextSize(Style.dp(11));
            c.drawText(l[i], left + bw / 2f, h - Style.dp(8), t);
        }
    }
}
