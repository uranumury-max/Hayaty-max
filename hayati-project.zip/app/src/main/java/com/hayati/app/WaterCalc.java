package com.hayati.app;

public class WaterCalc {
    /** Daily water goal in ml. A general estimate, not medical advice. */
    public static int goal(Store s) {
        float w = 0;
        try {
            w = Float.parseFloat(s.s("weight", "0"));
        } catch (Exception ignored) {
        }
        if (w <= 0) return 2000;
        int[] a = AgeCalc.age(s.s("birth", ""));
        int age = a == null ? 30 : a[0];
        float perKg = age < 18 ? 40f : (age <= 55 ? 35f : 30f);
        float ml = w * perKg;
        if (s.i("gender", 0) == 1) ml *= 0.95f;
        if (s.i("mood", 0) == 2) ml += 500f;
        int r = Math.round(ml / 50f) * 50;
        return Math.max(1200, r);
    }
}
