package com.hayati.app;

import java.util.Calendar;

public class AgeCalc {
    /** returns {years, months, days} or null when the date is missing/invalid */
    public static int[] age(String birth) {
        try {
            String[] p = birth.split("-");
            int by = Integer.parseInt(p[0]);
            int bm = Integer.parseInt(p[1]);
            int bd = Integer.parseInt(p[2]);
            Calendar now = Calendar.getInstance();
            int y = now.get(Calendar.YEAR) - by;
            int m = now.get(Calendar.MONTH) + 1 - bm;
            int d = now.get(Calendar.DAY_OF_MONTH) - bd;
            if (d < 0) {
                Calendar prev = (Calendar) now.clone();
                prev.set(Calendar.DAY_OF_MONTH, 1);
                prev.add(Calendar.MONTH, -1);
                d += prev.getActualMaximum(Calendar.DAY_OF_MONTH);
                m--;
            }
            if (m < 0) {
                m += 12;
                y--;
            }
            if (y < 0) return null;
            return new int[]{y, m, d};
        } catch (Exception e) {
            return null;
        }
    }
}
