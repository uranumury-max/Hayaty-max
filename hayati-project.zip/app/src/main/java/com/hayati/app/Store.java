package com.hayati.app;

import android.content.Context;
import android.content.SharedPreferences;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class Store {
    public final SharedPreferences sp;

    public Store(Context c) {
        sp = c.getSharedPreferences("hayati", Context.MODE_PRIVATE);
    }

    public String s(String k, String d) { return sp.getString(k, d); }
    public int i(String k, int d) { return sp.getInt(k, d); }
    public boolean b(String k, boolean d) { return sp.getBoolean(k, d); }

    public void put(String k, String v) { sp.edit().putString(k, v).apply(); }
    public void put(String k, int v) { sp.edit().putInt(k, v).apply(); }
    public void put(String k, boolean v) { sp.edit().putBoolean(k, v).apply(); }
    public void remove(String k) { sp.edit().remove(k).apply(); }

    public static String today() { return dayKey(0); }

    public static String dayKey(int daysAgo) {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_YEAR, -daysAgo);
        return new SimpleDateFormat("yyyyMMdd", Locale.US).format(c.getTime());
    }

    public int water(String dayKey) { return i("w_" + dayKey, 0); }

    public void addWater(int ml) {
        String k = "w_" + today();
        put(k, Math.max(0, i(k, 0) + ml));
    }

    public void resetWater() { put("w_" + today(), 0); }
}
