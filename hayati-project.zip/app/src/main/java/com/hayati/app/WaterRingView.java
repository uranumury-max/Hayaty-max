package com.hayati.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;

public class WaterRingView extends View {
    private final Paint ringBg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint arc = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint wave = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint small = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path wp = new Path();
    private final Path clip = new Path();
    private final RectF rect = new RectF();
    private float shown = 0f, target = 0f, phase = 0f;
    private int cur = 0, goal = 1;
    private ValueAnimator prog, wav;

    public WaterRingView(Context c) {
        super(c);
        txt.setTextAlign(Paint.Align.CENTER);
        txt.setTypeface(Typeface.DEFAULT_BOLD);
        small.setTextAlign(Paint.Align.CENTER);
    }

    public void setData(int cur, int goal) {
        this.cur = cur;
        this.goal = Math.max(1, goal);
        target = Math.min(1f, (float) cur / this.goal);
        if (prog != null) prog.cancel();
        prog = ValueAnimator.ofFloat(shown, target);
        prog.setDuration(900);
        prog.setInterpolator(new DecelerateInterpolator());
        prog.addUpdateListener(a -> {
            shown = (float) a.getAnimatedValue();
            invalidate();
        });
        prog.start();
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        wav = ValueAnimator.ofFloat(0f, (float) (Math.PI * 2));
        wav.setDuration(2600);
        wav.setRepeatCount(ValueAnimator.INFINITE);
        wav.setInterpolator(new LinearInterpolator());
        wav.addUpdateListener(a -> {
            phase = (float) a.getAnimatedValue();
            invalidate();
        });
        wav.start();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (wav != null) wav.cancel();
        if (prog != null) prog.cancel();
        shown = target;
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        float sw = Style.dp(12);
        float cx = w / 2f, cy = h / 2f;
        float r = Math.min(w, h) / 2f - sw;
        float inner = r - sw / 2f;

        ringBg.setStyle(Paint.Style.STROKE);
        ringBg.setStrokeWidth(sw);
        ringBg.setColor(Style.blend(Style.text, Style.card, 0.85f));
        c.drawCircle(cx, cy, r, ringBg);

        clip.reset();
        clip.addCircle(cx, cy, inner, Path.Direction.CW);
        c.save();
        c.clipPath(clip);
        float level = cy + inner - 2f * inner * shown;
        float amp = Style.dp(7) * Math.min(1f, Math.min(shown, 1f - shown) * 6f);
        wp.reset();
        wp.moveTo(0, h);
        for (float x = 0; x <= w; x += 4) {
            float y = level + (float) Math.sin(x / w * Math.PI * 3 + phase) * amp;
            wp.lineTo(x, y);
        }
        wp.lineTo(w, h);
        wp.close();
        wave.setStyle(Paint.Style.FILL);
        wave.setColor(Style.alpha(Style.accent, 0x66));
        c.drawPath(wp, wave);
        c.restore();

        rect.set(cx - r, cy - r, cx + r, cy + r);
        arc.setStyle(Paint.Style.STROKE);
        arc.setStrokeWidth(sw);
        arc.setStrokeCap(Paint.Cap.ROUND);
        arc.setColor(shown >= 0.999f ? Style.important : Style.accent);
        c.drawArc(rect, -90, 360f * shown, false, arc);

        txt.setColor(Style.text);
        txt.setTextSize(r * 0.42f);
        c.drawText(Math.round(shown * 100) + "%", cx, cy + txt.getTextSize() * 0.3f, txt);
        small.setColor(Style.sub);
        small.setTextSize(r * 0.16f);
        c.drawText(cur + " مل", cx, cy + r * 0.55f, small);
    }
}
